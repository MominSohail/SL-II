#include<stdio.h>
#include<stdlib.h>
#define SIZE 16

int padding(int num);
void input(int[][SIZE],int,int);
void Addition(int[][SIZE],int[][SIZE],int[][SIZE],int);
void Subtraction(int[][SIZE],int[][SIZE],int[][SIZE],int);
void Multiply(int[][SIZE],int[][SIZE],int[][SIZE]);
void Strassen(int[][SIZE],int[][SIZE],int[][SIZE],int);
void Display(int[][SIZE],int);

static int total_add=0,total_mult=0;

int main()
{
	int MatA[SIZE][SIZE],MatB[SIZE][SIZE],Result[SIZE][SIZE],num,temp;
	int i,j;
	printf("\n\tEnter the size of the Matrix::");
	scanf("%d",&num);
	if(num<=0)
		return 0;
	temp=num;
	num=padding(num);

	printf("Enter the Elements For Matrix A::\n");
	input(MatA,temp,num);
	printf("\n\nEnter the Elements For Matrix B::\n");
	input(MatB,temp,num);
	//Display Both the Matrices
	printf("\nMatrix A::\n");
	Display(MatA,num);

	printf("\nMatrix B::\n");	
	Display(MatB,num);

	Strassen(MatA,MatB,Result,num);
	printf("\nMultiplication of Matrix A and Matrix B::\n");
	Display(Result,temp);	
}

void input(int Mat[][SIZE],int temp,int num)
{
	int i,j;
	for(i=0;i<temp;i++)
	{
		for(j=0;j<temp;j++)
		{
			printf("\tElement[%d][%d]::",i,j);
			scanf("%d",&Mat[i][j]);
		}
		for(j=temp;j<num;j++)
			Mat[i][j]=0;
	}
	for(i=temp;i<num;i++)
	{
		for(j=0;j<num;j++)
			Mat[i][j]=0;
	}
}
void Display(int Mat[][SIZE],int num)
{
	int i,j;
	for(i=0;i<num;i++)
	{
		for(j=0;j<num;j++)
		{
			printf("\t%d",Mat[i][j]);
		}
		printf("\n");
	}
}

int padding(int num)
{
	int original_num=num,actual_num=1,lower_power=0,i;
	if(num==1)
		return 1;
	while(num>1)
	{
		lower_power++;
		num=num/2;
	}
	for(i=0;i<lower_power;i++)
	{
		actual_num=actual_num*2;
	}
	if(actual_num==original_num)
		return original_num;
	else
		return actual_num*2;
}

void Addition(int MatA[][SIZE],int MatB[][SIZE],int Result[][SIZE],int size)
{
	int i,j;
	for(i=0;i<size;i++)
	{
		for(j=0;j<size;j++)
		{
			Result[i][j]=MatA[i][j]+MatB[i][j];
			total_add++;
		}
	}
}


void Subtraction(int MatA[][SIZE],int MatB[][SIZE],int Result[][SIZE],int size)
{
	int i,j;
	for(i=0;i<size;i++)
	{
		for(j=0;j<size;j++)
		{
			Result[i][j]=MatA[i][j]-MatB[i][j];
			total_add++;
		}
	}
}

void Multiply(int MatA[][SIZE],int MatB[][SIZE],int Result[][SIZE])
{
	int p1,p2,p3,p4,p5,p6,p7;
	p1=(MatA[0][0]+MatA[1][1])*(MatB[0][0]+MatB[1][1]);
	p2=(MatA[1][0]+MatA[1][1])*MatB[0][0];
	p3=(MatA[0][0])*(MatB[0][1]-MatB[1][1]);
	p4=(MatA[1][1])*(MatB[1][0]-MatB[0][0]);
	p5=(MatA[0][0]+MatA[0][1])*(MatB[1][1]);
	p6=(MatA[1][0]-MatA[0][0])*(MatB[0][0]+MatB[0][1]);
	p7=(MatA[0][1]-MatA[1][1])*(MatB[1][0]+MatB[1][1]);

	Result[0][0]=p1+p4-p5+p7;
	Result[0][1]=p3+p5;
	Result[1][0]=p2+p4;
	Result[1][1]=p1+p3-p2+p6;
	
	total_add=total_add+18;
	total_mult=total_mult+7;

}


void Strassen(int MatA[][SIZE],int MatB[][SIZE],int Result[][SIZE],int size)
{
	int A11[SIZE][SIZE],A12[SIZE][SIZE],A21[SIZE][SIZE],A22[SIZE][SIZE],B11[SIZE][SIZE],B12[SIZE][SIZE],B21[SIZE][SIZE],B22[SIZE][SIZE];
	int C11[SIZE][SIZE],C12[SIZE][SIZE],C21[SIZE][SIZE],C22[SIZE][SIZE];

	int P1[SIZE][SIZE],P2[SIZE][SIZE],P3[SIZE][SIZE],P4[SIZE][SIZE],P5[SIZE][SIZE],P6[SIZE][SIZE],P7[SIZE][SIZE];
	int temp1[SIZE][SIZE],temp2[SIZE][SIZE],temp3[SIZE][SIZE];

	int NewSize=0,i,j,k;
	
	if(size<=2)
	{
		Multiply(MatA,MatB,Result);
	}
	else
	{
		NewSize=size/2;
		for(i=0;i<NewSize;i++)
		{
			for(j=0;j<NewSize;j++)
			{
				A11[i][j]=MatA[i][j];
				A12[i][j]=MatA[i][j+NewSize];
				A21[i][j]=MatA[i+NewSize][j];
				A22[i][j]=MatA[i+NewSize][j+NewSize];

				B11[i][j]=MatB[i][j];
				B12[i][j]=MatB[i][j+NewSize];
				B21[i][j]=MatB[i+NewSize][j];
				B22[i][j]=MatB[i+NewSize][j+NewSize];
			}
		}
		//calculation of p1
		Addition(A11,A22,temp1,NewSize);
		Addition(B11,B22,temp2,NewSize);
		Strassen(temp1,temp2,P1,NewSize);
		
		//calculation of P2
		Addition(A21,A22,temp1,NewSize);
		Strassen(temp1,B11,P2,NewSize);

		//calculation of P3
		Subtraction(B12,B22,temp1,NewSize);
		Strassen(A11,temp1,P3,NewSize);

		//calculation of P4
		Subtraction(B21,B11,temp1,NewSize);
		Strassen(A22,temp1,P4,NewSize);

		//calculation of P5
		Addition(A11,A12,temp1,NewSize);
		Strassen(temp1,B22,P5,NewSize);

		//calculation of P6
		Subtraction(A21,A11,temp1,NewSize);
		Addition(B11,B12,temp2,NewSize);
		Strassen(temp1,temp2,P6,NewSize);

		//calculation of P7
		Subtraction(A12,A22,temp1,NewSize);
		Addition(B21,B22,temp2,NewSize);
		Strassen(temp1,temp2,P7,NewSize);

		//calcuation of C11
		Addition(P1,P4,temp1,NewSize);
		Addition(temp1,P7,temp2,NewSize);
		Subtraction(temp2,P5,C11,NewSize);

		//calculation of C12
		Addition(P3,P5,C12,NewSize);
		
		//calculation of C21
		Addition(P2,P4,C21,NewSize);

		//calculation of C22
		Addition(P1,P3,temp1,NewSize);
		Addition(temp1,P6,temp2,NewSize);
		Subtraction(temp2,P2,C22,NewSize);

		for(k=0;k<NewSize;k++)
		{
			for(j=0;j<NewSize;j++)
			{
				Result[k][j]=C11[k][j];
				Result[k][j+NewSize]=C12[k][j];
				Result[k+NewSize][j]=C21[k][j];
				Result[k+NewSize][j+NewSize]=C22[k][j];
			}
		}	
	}	
}

/*
 ============================================================================
 Name        : nQueen.c
 Author      :
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include<math.h>

int Place(int k,int i);
void NQueens(int k, int Q);
void showBoard(int Q);
int chess[20],count=0;

int main(void) {
	int Q;
	printf("Enter How many Queen You Want To place:");
		scanf("%d",&Q);
		printf("Number Of Queen Given are %d hence Need %d*%d Chess Board",Q,Q,Q);

		NQueens(1,Q);

	return EXIT_SUCCESS;
}

void NQueens(int k,int Q)
{
	int i;
	for(i=1;i<=Q;i++)
	{
		if(Place(k,i))
		{
		chess[k]=i;
		if(k==Q)
			showBoard(Q);
		else
			NQueens(k+1,Q);
		}
	}
}

int Place(int k,int i)
{
	int j;
	for(j=1;j<=k-1;j++)
	{
		if((chess[j]==i) || (abs(chess[j]-i)==abs(j-k)))
			return 0;
	}

	return 1;
}

void showBoard(int Q)
{

	 int i,j;
	 printf("\n\nPossible Solution %d:\n\n",++count);

	 for(i=1;i<=Q;++i)
	 { printf("\t%d",i); }//print column number

	 for(i=1;i<=Q;++i)
	 {
	  printf("\n\n%d",i); //print row number
	  for(j=1;j<=Q;++j)
	  {
	   if(chess[i]==j)
	    printf("\tQ");
	   else
	    printf("\t-");
	  }
	 }
     printf("\n=================================================\n");
}

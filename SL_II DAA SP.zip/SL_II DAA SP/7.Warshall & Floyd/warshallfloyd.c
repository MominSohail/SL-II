#include <stdio.h>
#include <stdlib.h>

void warshall(int [][10],int);
void floyd(int [][10],int);
int min(int,int);
int main(void)
{
	int w[10][10];
	int n,i,j;
	printf("\nEnter number Of Vertices :: ");
	scanf("%d",&n);
	printf("\nEnter weight (99 for infinity) :: \n");
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			printf("\nWeight [%d,%d] :: ",i,j);
			scanf("%d",&w[i][j]);
		}
	}
	warshall(w,n);
	floyd(w,n);

	return EXIT_SUCCESS;
}

void floyd(int w[][10],int n)
{
	int d[10][10];
	int i,j,k;
	printf("D[0] :: \n");
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			d[i][j]=w[i][j];
			printf("| %4d    |",d[i][j]);  // the “4” tells the printf to format the output to a length of 4 characters
		}
		printf("\n");
	}
	for(k=1;k<=n;k++)
	{
		printf("\n\nFloyd D[%d] :: \n",k);
		for(i=1;i<=n;i++)
		{
			for(j=1;j<=n;j++)
			{
				d[i][j]=min(d[i][j],d[i][k]+d[k][j]);
				printf("| %4d    |",d[i][j]);
			}
			printf("\n");
		}

	}
	printf("\n\nFinal Floyd Result :: \n");
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			printf("| %4d    |",d[i][j]);
		}
		printf("\n");
	}

}

void warshall(int w[][10],int n)
{
	int d[10][10];
	int i,j,k;
	printf("D[0] :: \n");
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			d[i][j]=w[i][j];
                   if(d[i][j]!=0 && d[i][j]!=99)
                           d[i][j]=1;
                   else
                            d[i][j]=0;
			printf("| %4d    |",d[i][j]);
		}
		printf("\n");
	}
	for(k=1;k<=n;k++)
	{
		printf("\n\nWarshall D[%d] :: \n",k);
		for(i=1;i<=n;i++)
		{
			for(j=1;j<=n;j++)
			{
				d[i][j]=(d[i][j] || (d[i][k] && d[k][j]));
				printf("| %4d    |",d[i][j]);
			}
			printf("\n");
		}
	}
	printf("\n\nFinal Warshall Result :: \n");
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			printf("| %4d    |",d[i][j]);
		}
		printf("\n");
	}

}

int min(int a,int b)
{
	if(a<=b)
		return a;
	else
		return b;
}



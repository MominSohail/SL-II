#include <stdio.h>
#define INF 999
#define MAX 10

int visited[MAX], tsp_cost[MAX][MAX], original_cost[MAX][MAX], cost[20], n, l=0;
int node_no = 1;

void display_path()
{
	int i,cost=0;
	printf("\n THE PATH OF THE TOUR IS : ");
	for( i = 0;i < n;i++)
	{
	printf("%d  ->" ,visited[i] + 1 );
	}

	printf(" 1 \n");
	visited[i]=0;				//Going back to first city after visiting the last city

	//calculate cost from original distance matrix by adding distances
	for(i=0;i<n;i++)
	{
	printf("\n %d -> %d = %d ",(visited[i]+1),(visited[i+1]+1),original_cost[visited[i]][visited[i+1]]);	//display distance betwn cities
	cost+=original_cost[visited[i]][visited[i+1]];
	}
	printf("\n\n MINIMUM COST OF THE TOUR IS : %d",cost);
}


// find min in current row r
int find_row_min(int b[][10],int r)
{
	int j,min = INF;
	for( j = 0;j < n;j++)
	{
		if(b[r][j] < min)
			min = b[r][j];
	}
	if(min == INF)					//if row contains only infinity return min value as 0 since we can't reduce it
		min = 0;
  	return min;
}

// find min in current column c
int find_col_min(int b[][10],int c)
{
	int i,min = INF;
	for(i = 0;i < n;i++)
	{
		if(b[i][c] < min)
			min = b[i][c];
	}
	if(min == INF) 					//if column contains only infinity return min value as 0 since we can't reduce it
	min = 0;
	return min;
}

//to reduce matrix
int reduced_matrix(int b[10][10])
{
	int reduced_sum = 0,min,i,j;

	//row reduction
	for( i = 0;i < n;i++)
	{
		min = find_row_min(b,i);
		reduced_sum += min;
		for(j = 0;j < n;j++)
		{
			if(b[i][j] != INF)
				b[i][j] -= min;
		}
	}

	// column reduction
	for( i = 0;i < n;i++)
	{
		min = find_col_min(b,i);
		reduced_sum += min;
		for( j = 0;j < n;j++)
		{
			if(b[j][i] != INF)
				b[j][i] -= min;
		}
	}

	printf("\n\n");
	printf(" REDUCED MATRIX FOR CITY %d: \n",node_no++);
	for(i = 0;i < n;i++)
	{
		for(j = 0;j < n;j++)
			printf(" %d ",b[i][j]);
		printf("\n");
	}
	return reduced_sum;
}

// finding min  value or min cost of node from given set of nodes to choose the node to be expanded further
int min1(int temp[][2],int q)
{
	int small = 999,j,i;
	for(i = 0;i < q;i++)
	{
		if(temp[i][1] < small)
		{
			small = temp[i][1];
			j = i;
		}
	}
	return j;
}

// to check visited nodes
int check_visited(int k)
{
	int i;
	for( i = 0;i < l;i++)
	{
		if(visited[i] == k)
			return 1;
	}
	return 0;
}

// matrix reduction for branch as per bound (condition)
void dynamic_reduction()
{
	int temp[10][2],q,p,m[10][10],sum=0,i,j,k;
	while(l < n)
	{
		q = 0;				//check all the unvisited nodes left to be travelled or nodes left to be expanded
		for(i = 0;i < n;i++)
		{
			p = check_visited(i);
			if(p == 0)		   //q- holds no of nodes to be expanded yet
			temp[q++][0] = i;  //temp is a 2-d array it holds the node no in temp[x][0] and cost of that node in temp[x][1]
		}

		for(i = 0;i < q;i++)
		{
			//copy full reduced matrix a to matrix m for dynamic reduction;
			for( k = 0;k < n;k++)
			{
				for(j = 0;j < n;j++)
					m[k][j] = tsp_cost[k][j];
			}

			for(k = 0;k < l;k++)
			{
				for(j = 0;j < n;j++)
					m[visited[k]][j] = INF; 	// make row infinity for visited city
			}

			for( k = 1;k < l;k++)
			{
				for(j = 0;j < n;j++)
				{
					m[j][visited[k]] = INF; 	// make col infinity  for next visited city
				}
			}

			for(j = 0;j < n;j++) 			// make col infinity for the city to be visited
				m[j][temp[i][0]] = INF;

			for(j = 0;j < n;j++) 			// make m[j][i] infinity  for i to j path
			{
				if(visited[j+1] != -1)
					m[visited[j+1]][0] = INF;
			}

			m[temp[i][0]][0] = INF;			//make m[i][1]-> infinity
			sum = reduced_matrix(m);
			temp[i][1] = cost[0] + sum + tsp_cost[visited[l-1]][temp[i][0]];	//calculate cost of node
			//formula-> cost of node= optimal cost of node 1 + reduced cost (if any) of this node + M[i][j]
			printf("\n COST OF NODE NO. %d : %d \n", node_no-1,temp[i][1]);
		}
		p = min1(temp,q);         				//find minimum cost node as E-node
		visited[l] = temp[p][0];
		cost[l++] = temp[p][1];
		printf("\n MINIMUM COST CITY IS %d AND ITS COST IS %d \n\n",temp[p][0]+1,temp[p][1]);
	}
}

int main(void)
{
	int i,j;
	printf("\n\t TRAVELLING SALESMAN PROBLEM USING BRANCH AND BOUND:: ");
	printf("\n\n ENTER NUMBER OF CITIES : \n");
	scanf("%d",&n);
	printf("\n ENTER COST MATRIX : \n");
	for(i = 0;i < n;i++){
		printf("\nRow (%d):",i+1);
		for(j = 0;j < n;j++)
		{
			printf("\nMatrix[%d][%d]:",i+1,j+1);
			scanf("%d",&tsp_cost[i][j]);
			original_cost[i][j]=tsp_cost[i][j];
		}
	}

	printf("\n COST MATRIX\n");
	for(i = 0;i < n;i++)
	{
		for(j = 0;j < n;j++)
			printf(" %d ",tsp_cost[i][j]);
		printf("\n");
	}
	printf("\n");

	//step 1- The distance 0 is converted to Infinity for further computations
	for(i = 0;i < n;i++)
	{
		for(j = 0;j < n;j++)
		{
			if(tsp_cost[i][j]==0)
				tsp_cost[i][j]=INF;
		}
	}

	visited[l] = 0;
	cost[l++] = reduced_matrix(tsp_cost);
	printf("\n Optimal Cost for Node 1:: %d\n",cost[0]);
	dynamic_reduction();
	display_path();
	printf("\n\n");

}



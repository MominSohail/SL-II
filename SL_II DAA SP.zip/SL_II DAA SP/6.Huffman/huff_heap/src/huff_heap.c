#include<string.h>
#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
        char ch;
        int freq;
        struct node *left;
        struct node *right;
}node;

void decode(node *);
node * heap[20];
int size;

void Init()
{
        size = 0;
        heap[0] = (node *)malloc(sizeof(node));
        heap[0]->freq = -1000;

}

void ins(node * ele)
{
        size++;
        heap[size] = ele;
        int now = size;
        while(  heap[now/2] -> freq > ele -> freq  )
        {
                heap[now] = heap[now/2];
                now /= 2;
        }
        heap[now] = ele;
}
node * delmin()
{
        node * minele,*lastele;
        int child,now;
        minele = heap[1];
        lastele = heap[size--];
        for(now = 1; now*2 <= size ;now = child)
        {

                child = now*2;

                if(child != size && heap[child+1]->freq < heap[child] -> freq )
                {
                        child++;
                }

                if(lastele -> freq > heap[child] -> freq)
                {
                        heap[now] = heap[child];
                }
                else
                {
                        break;
                }
        }
        heap[now] = lastele;
        return minele;
}

void    display(node *temp,char *code)
{
        if(temp->left==NULL && temp->right==NULL)
        {
                printf("Character:: %c || Code:: %s\n",temp->ch,code);
                return;
        }
        int len = strlen(code);
        char lc[512],rc[512];
        strcpy(lc,code);
        strcpy(rc,code);
        lc[len] = '0';
        lc[len+1] = '\0';
        rc[len] = '1';
        rc[len+1] = '\0';
      display (temp->left,lc);
       display(temp->right,rc);
}


void decode(node *root)
{
    char code[20],data[20];
    node *temp=NULL;
    int i=0,j=0;
    printf("\n\t Enter the code to be decoded :: ");
    scanf("%s",code);
    while(code[i]!='\0')
    {
        temp=root;
        while((temp->left!=NULL && temp->right!=NULL ) && code[i]!='\0')
        {
            if(code[i]=='1')
                 temp=temp->right;
            else if(code[i]=='0')
                temp=temp->left;
            i++;
        }
        if(temp->left==NULL && temp->right==NULL)
            data[j++]=temp->ch;
        else
        {
            printf("Error ");
            exit(0);
        }
    }
    data[j]='\0';
    printf("\n Decoded Data :: %s",data);
}

int main()
{
        Init();
        int distinct_char,freq,i ;
        printf("\n-->Enter the no.of elements::\n");
        scanf("%d",&distinct_char);
        char ch;
        printf("\n-->Enter the Character and Frequency::\n");
        for(i=0;i<distinct_char;i++)
        {
                node * temp = (node *) malloc(sizeof(node));
                scanf(" %c",&temp->ch);
                scanf("%d",&temp->freq);
                temp -> left = temp -> right = NULL;
                ins(temp);
        }
        if(distinct_char==1)
        {
                printf("char %c code 0\n",ch);
                return 0;
        }
        for(i=0;i<distinct_char-1 ;i++)
        {
                node * left = delmin();
                node * right = delmin();
                node * temp = (node *) malloc(sizeof(node));
                temp -> ch = 0;
                temp -> left = left;
                temp -> right = right;
                temp -> freq = left->freq + right -> freq;
                ins(temp);
        }
        node *tree = delmin();
        char code[512];
        code[0] = '\0';
       display(tree,code);
        decode(tree);
        return 0;
}

/*
**********************************OUTPUT*********************************
-->Enter the no.of elements::
4

-->Enter the Character and Frequency::
1 5
5 3
2 7
7 4
Character:: 2 || Code:: 0
Character:: 1 || Code:: 10
Character:: 5 || Code:: 110
Character:: 7 || Code:: 111

	 Enter the code to be decoded :: 110100

 Decoded Data :: 512
*/

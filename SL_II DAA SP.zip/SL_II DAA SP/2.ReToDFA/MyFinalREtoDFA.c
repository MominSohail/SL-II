#include <stdio.h>
#include <stdlib.h>

typedef struct tree
{
	struct tree *L,*R;
	char data;
	int nullable;
	int firstpos[10];
	int lastpos[10];
	int position;
}Node;

struct follow
{
	int a;
	char d;
	int follo[10];
}F[10];


struct dstate
{
	int state[10];

}DS[20];

Node *S[10];
int top=-1;

void push(Node *p)
{
	S[++top]=p;
}

Node *pop()
{
 Node *temp;
      if(top!=-1)
      {
    	  temp=S[top];
    	  top--;
	return temp;
      }
      return NULL;
}

Node *getnode()
{
	Node *N=NULL;
    int i;
	N=(Node *)malloc(sizeof(Node));
	N->L=NULL;
			N->R=NULL;
	for(i=0;i<=10;i++)
	{
		N->firstpos[i]=-1;
		N->lastpos[i]=-1;
	}
	return N;
}

void un(int a[30], int a1[15],int a2[15])///function definition for Union
{
	int i,j;

	    for(i=0;a1[i]!=-1;i++)
	    {
	    	for(j=0;a[j]!=-1;j++)
	    	{
	    		if(a[j]==a1[i])
	    			break;
	    	}
	    	 if(a[j]==-1)
	    		  a[j]=a1[i];
	    }

	    for(i=0;a2[i]!=-1;i++)
	    {
	        for(j=0;a[j]!=-1;j++)
	            if(a[j]==a2[i])
	                break;

	        if(a[j]==-1)
	        {
	            a[j]=a2[i];
	        }
	    }
}


Node *Tree(char str[30])
{
	Node *root=NULL;
	int i=0,j=1;
while(str[i]!='\0')
{
		Node *p;
		p=getnode();
		p->data=str[i];
	 if(isalpha(p->data) || p->data=='#' || p->data=='@')
	 {
		 if(p->data=='@')
		 {
			 p->nullable=1;
		 }
		 else
		 {
		 p->nullable=0;
		 p->firstpos[0]=j;
		 p->lastpos[0]=j;
		 }
		 p->position=j;
		 j++;
		 push(p);
	 }
	 else if(p->data=='|' || p->data=='.' || p->data=='+')
	 {
		 if(top==-1)
		 		{
		 			printf("\nINVALID RE....");
		 			exit(0);
		 		}
		 p->R=pop();
		 if(top==-1)
		 		{
		 			printf("\nINVALID RE....");
		 			exit(0);
		 		}
		 p->L=pop();
         p->position=0;
		 if(p->data=='|' || p->data=='+')
		 {
			 p->nullable=(p->L->nullable || p->R->nullable);
			 un(p->firstpos,p->L->firstpos,p->R->firstpos);
			 un(p->lastpos,p->L->lastpos,p->R->lastpos);
			 push(p);
		 }
		 else if(p->data=='.')
		 {
			 p->nullable=(p->L->nullable && p->R->nullable);

			 if(p->L->nullable)
			 { un(p->firstpos,p->L->firstpos,p->R->firstpos);}
			 else
				 {un(p->firstpos,p->L->firstpos,p->L->firstpos);}

			 if(p->R->nullable)
			 	{un(p->lastpos,p->L->lastpos,p->R->lastpos);}
			 else
			 { un(p->lastpos,p->R->lastpos,p->R->lastpos);}

           push(p);
		 }
	 }
  else if(p->data=='*')
		 {
	  if(top==-1)
	  		{
	  			printf("\nINVALID RE....");
	  			exit(0);
	  		}
	         p->L=pop();
	  		 p->position=0;
	  p->nullable=1;

	        un(p->firstpos,p->L->firstpos,p->L->firstpos);

			 un(p->lastpos,p->L->lastpos,p->L->lastpos);
			 push(p);
		 }

  else
     {
	  printf("\nINVALID RE....");
	  			exit(0);
      }

	 i++;
	}

	if(top==-1)
		printf("Not Perfect Tree");
	else
		{
		root=pop();
		if(top!=-1)
		{
			printf("\nINVALID RE....");
			exit(0);
		}
		}

	return root;
}

void postorder(Node *T)
{
	int i;
	if(T!=NULL)
	{
		postorder(T->L);
		postorder(T->R);
			printf("\n%c\t\t%d\t\t%d\t\t{",T->data,T->nullable,T->position);
		i=0;
		while(T->firstpos[i]!=-1)
			  {
			   printf("%d ",T->firstpos[i]);
			  i++;
			  }
		  printf("}\t\t\t{");
		  i=0;
		  while(T->lastpos[i]!=-1)
		  			  {
			  printf("%d ",T->lastpos[i]);
			  i++;
		  			  }
		  printf("}");
	}
}

void init_follo()
{
	int i,j;
	for(i=0;i<=10;i++)
	{

		F[i].a=-1;
		j=0;
		while(j<=10)
		{
			F[i].follo[j]=-1;

			j++;
		}
	}

}

void follow(Node *T)
{
	int i=0;

	if(T!=NULL)
	{
        follow(T->L);
		follow(T->R);
       if(T->data=='.')
       {
    	   i=0;
    	   while(T->L->lastpos[i]!=-1)
    	   {
    		   F[T->L->lastpos[i]].a=T->L->lastpos[i];

             un(F[T->L->lastpos[i]].follo,F[T->L->lastpos[i]].follo,T->R->firstpos);
    	   i++;
    	   }
       }
       else if(T->data=='*')
       {
    	   i=0;
    	   while(T->lastpos[i]!=-1)
    	   {
    		   F[T->lastpos[i]].a=T->lastpos[i];

    		   un(F[T->lastpos[i]].follo,F[T->lastpos[i]].follo,T->firstpos);
    	   i++;
    	   }

       }

	}
}
void map(Node *T)
{
	int i=1;
	if(T!=NULL)
		{
		  map(T->L);
		  map(T->R);
		  for(i=1;F[i].a!=-1;i++)
		  {
              if(F[i].a==T->position)
            	  F[i].d=T->data;
		  }
		}
}

void dis_follow()
{
	int j=0,i=1;
	printf("\n\nFollow Position Table:");
	printf("\nLeaf Node Position \t Symbol at position \t Follow Position");
	while(F[i].a!=-1)
	{
       j=0;
       printf("\n %d\t\t\t  %c\t\t\t{",F[i].a,F[i].d);
		while(F[i].follo[j]!=-1)
		{
			printf("%d ",F[i].follo[j]);
			j++;
		}
		printf("}");
		i++;
	}
   printf("\n==============================================================\n");
}

int ArrEql(int A1[],int A2[])
{
    int i;
         for(i=0;A1[i]!=-1;i++)
           {
                if(A1[i]==A2[i])
                  continue;
                else
                	return 0;
            }
         if(A1[i]==-1 && A2[i]==-1)
        	 return 1;
    return 0;
}

int store(int result[],struct dstate DS[20],int *totalstates)
{
    int i;
    for(i=0;i<*totalstates;i++)
    {
        if(ArrEql(result,DS[i].state))
            break;
    }
    if(i==*totalstates)
    {

        un(DS[*totalstates].state,DS[*totalstates].state,result);
    	 *totalstates+=1;
    }
    return i;
}

void display(struct dstate DS[20],int trans[][10],int totalstates,char alpha[])
{
    int i,j;
    printf("\n\nTotal states = %d",totalstates);


    printf("\n\n\tTRANSITION TABLE");

    printf("\n-------------------------------------------");
    printf("\nStates");

    for(i=0;alpha[i]!='\0';i++)
        printf("\t%c",alpha[i]);
    printf("\n-------------------------------------------");
    for(i=0;i<totalstates;i++)
    {
        printf("\n%c\t ",i+65);
        for(j=0;trans[i][j]!=-1;j++)
        {
            printf("\t%c",trans[i][j]);
        }
    }
    printf("\n-------------------------------------------");

}

void REtoDFA(Node *T)
{
	int result[10],curr[10],i,j,k,tostates,totalstates=1,flag=0;
	    char alpha[10];
	    int trans[10][10];
	    for(i=0;i<10;i++)
	    {
	        curr[i]=-1;
	        alpha[i]='?';
	        for(j=0;j<10;j++)
	             trans[i][j]=-1;
	    }

	    for(i=1;F[i].a!=-1;i++)
	    {
	        for(j=0;alpha[j]!='?';j++)
	        {
	            if(alpha[j]==F[i].d)
	                break;
	        }
	        if(alpha[j]=='?')
	            alpha[j]=F[i].d;
	    }
	    alpha[j+1]='\0';
	    i=0;
	    printf("\nAll Inputs:");
	    while(alpha[i]!='\0')
	    {
	    	printf("\n %c",alpha[i]);
	    	i++;
	    }
	    for(i=0;i<20;i++) //initialize transition structure
	    {
	    	for(j=0;j<10;j++)
	    	{
	    		DS[i].state[j]=-1;
	    	}
	    }

	    un(DS[0].state,DS[0].state,T->firstpos);

	    for(k=0;k<totalstates;k++)
	    {
	    	for(i=0;i<10;i++)
	    		    curr[i]=-1;
	    	un(curr,curr,DS[k].state);

	        for(j=0;alpha[j]!='\0';j++)
	        {
	            for(i=0;i<10;i++)
	                result[i]=-1;
	            for(i=0;curr[i]!=-1;i++)
	            {
	                if(F[curr[i]].d==alpha[j])
	                {
	                	flag=1;
	               	un(result,result,F[curr[i]].follo);
	                }
	            }
	            if(flag==1)
	            {
	            tostates=store(result,DS,&totalstates);
	            trans[k][j]=tostates+65;
	            flag=0;
	            }
	            else
	            {
	            	trans[k][j]=NULL;
	            	flag=0;
	            }
	        }

	    }
	    display(DS,trans,totalstates,alpha);
}

int main(void)
{
  char RE[30];
   int i=0;
  printf("\nEnter Valid Regular Expression in Post fix form with input alphabets  separated . and #. at the end:\n");
  printf("\nNOTE: For epsilon use symbol @\n");
  gets(RE);

  while(RE[i]!='\0')
   i++;
  if(RE[i-1]=='.' && RE[i-2]=='#')
  {
  printf("\nGiven String :->");
  puts(RE);

  Node *Root;
  Root=Tree(RE);
  printf("\nSuccefully tree Created Root of Tree :-> %c ",Root->data);

 printf("\n\nAfter Tree Creation Table for POST FIX Traversal with All Values:");

 printf("\nCharacter\tNullabale\tPosition\tFirstPos\t\tLastPos\n");
 postorder(Root);
 printf("\n======================================================================================\n");

  init_follo();
  follow(Root);

  map(Root);
  dis_follow();

   REtoDFA(Root);
  }
  else
  {
	  printf("\nINVALID RE....It should End With #.");
	  exit(0);
  }
	return EXIT_SUCCESS;
}

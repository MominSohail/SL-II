#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 200

typedef struct MDT{
	int index;
	char str[10][MAX];
	int instruct_count;
}MDT;

typedef struct MNT{
	int index;
	char name[50];
	int pno;
	int kpno;
	int mdtp;
}MNT;

typedef struct PTAB{
	char pname[10][MAX];
	char value[10][MAX];
}PTAB;

typedef struct KPTAB{
	char kpname[10][MAX];
	char value [10][MAX];
}KPTAB;

typedef struct ALA{
	char name[10][MAX];
	char value[10][MAX];
}ALA;


MDT mdt[10];
MNT mnt[10];
PTAB ptab[10];
KPTAB kptab[10];
int counter=1;


void initialize(MDT mdt[10],MNT mnt[10])
{	int i;
	for(i=0;i<10;i++)
	{
		mdt[i].index=0;
		mdt[i].instruct_count=0;
		mnt[i].index=0;
		mnt[i].pno=0;
		mnt[i].kpno=0;
	}
}

void pass1()
{
	char s[MAX],s1[MAX],ch[10],temp[MAX];
	char delim[]=" \n";
	char *token;
	int instruction_counter=0,i,macro_name_line=0,j,pcount=0,kpcount=0,pflag,k;

	initialize(mdt,mnt);

	FILE *fpr=fopen("/home/momin/workspace/SP/myMACRO/src/input.txt","r");
	FILE *fpw=fopen("/home/momin/workspace/SP/myMACRO/src/intermediate.txt","w");

	while(!feof(fpr))
	{
		fgets(s,MAX,fpr);
		strcpy(s1,s);
		token=strtok(s,delim);
		if(strcmp(token,"MACRO")!=0)   //if MACRO is not present
		{
			fputs(s1,fpw);
		}
		else
		{                 //GOT MIACRO
			instruction_counter=0,macro_name_line=0,pcount=0,kpcount=0;
			fgets(s,MAX,fpr);
			strcpy(s1,s);
			token=strtok(s,delim);
                        //printf("\nin token :%c",*token);
			mdt[counter].index=counter;
			while(strcmp(token,"MEND")!=0)
			{
				if(macro_name_line==0)  //handle MACRO Arguments
				{
					for(i=0;i<counter;i++)
					{
						if(strcmp(mnt[i].name,token)==0)
						{
							printf("\nError: Two macros with same name cannot be present...");
							exit(0);
						}
					}
					mnt[counter].index=counter;
					mnt[counter].mdtp=mdt[counter].index;
					strcpy(mnt[counter].name,token);

					token=strtok(NULL,delim);

					while(token!=NULL)
					{
						if(strstr(token,"=")!=NULL) //if keyword parameter or keyword parameter with default value
						{
							mnt[counter].kpno++;
							i=0;
							while(token[i++]!='=');
							k=i;
							j=0;
							if(token[i]=='\0')  //if only keyword parameter
							{
								strcpy(temp,"");
							}
							else
							{               //if with default value
								while(token[i]!='\0')
								{
									temp[j++]=token[i++];
								}
								temp[j]='\0';
								token[k]='\0';
							}
                                                         //Make entries for parameter
							strcpy(kptab[counter].kpname[kpcount],token);
							strcpy(kptab[counter].value[kpcount++],temp);
							strcpy(ptab[counter].pname[pcount],token);
							strcpy(ptab[counter].value[pcount++],temp);

						}
						else        //if only positional parameter
						{
							mnt[counter].pno++;
							strcpy(ptab[counter].pname[pcount++],token);
						}
						token=strtok(NULL,delim);
					}
					macro_name_line=1;
				}
				else
				{	strcpy(s1," ");
					while(token!=NULL)
					{
						pflag=0;
						for(i=0;i<pcount;i++)
						{
							if(strstr(ptab[counter].pname[i],token)!=NULL)
								pflag=1;
							if(strcmp(token,ptab[counter].pname[i])==0 || pflag==1)
							{
								ch[0]='#';
								ch[1]=i+48;  //ASCII 48=0 we are converting integer value to its ASCII as ch character type
								ch[2]='\0';
								strcpy(token,ch);
								break;
							}
						}
						strcat(s1,token);
						strcat(s1," ");
						token=strtok(NULL,delim);
					}
					strcpy(mdt[counter].str[instruction_counter++],s1);
				}
				fgets(s,MAX,fpr);
				token=strtok(s,delim);
			}
			mdt[counter].instruct_count=instruction_counter;
			counter++;
		}
	}

	printf("\nMDT Details:\n");
	for(j=1;j<counter;j++)
	{	printf("#%d:\n",j);
	for(i=0;i<mdt[j].instruct_count;i++)
	{
		puts(mdt[j].str[i]);
	}
	}
	printf("\nMNT Details:\n");
	printf("\nSr.No\t Name \tPNO \t KPNO \t MDTP ");
	for(i=1;i<counter;i++)
	{
		printf("\n%d \t %s \t %d \t %d \t %d",mnt[i].index,mnt[i].name,mnt[i].pno,mnt[i].kpno,mnt[i].mdtp);

	}
   printf("\n*********************************************");
	printf("\n\nPTAB Details:\n");
	for(i=1;i<counter;i++)
	{
		printf("\nPTAB for %s:",mnt[i].name);
		printf("\nSr.No. \t Name");
		for(j=0;j<(mnt[i].pno+mnt[i].kpno);j++)
		{
			printf("\n%d \t %s",j,ptab[i].pname[j]);
		}
		printf("\n*****************************\n");
	}

	printf("\nKPTAB Details:\n");
	for(i=1;i<counter;i++)
	{
		printf("KTAB for %s:",mnt[i].name);
		printf("\nSr.No. \t Name \t Value");
		for(j=0;j<mnt[i].kpno;j++)
		{
			printf("\n%d \t %s \t%s",j,kptab[i].kpname[j],kptab[i].value[j]);
		}
		printf("\n*******************************\n");
	}
	fclose(fpr);
	fclose(fpw);
}

void pass2()
{
	FILE *fpr=fopen("/home/momin/workspace/SP/myMACRO/src/intermediate.txt","r");
	FILE *fpw=fopen("/home/momin/workspace/SP/myMACRO/src/MYoutput.txt","w");

	ALA ala[10];
    char s[MAX],delim[]=" \n",ch[MAX],s1[MAX];
	char *token;
	int i,j,k,l,mflag,temp_count,arg_flag,d;

	while(!feof(fpr))
	{
		temp_count=0;
		mflag=0;
		arg_flag=1;

		fgets(s,MAX,fpr);
		strcpy(s1,s);
		token=strtok(s,delim);

		for(i=0;i<counter;i++)//check in mnt it is macro call
		{
			if(strcmp(mnt[i].name,token)==0)
			{
				mflag=1;
				break;
			}
		}
		if(mflag==1)//if its a macro call
		{
			  // consturction of ALA for each MACRO call
			for(j=0;j<=mnt[i].pno+mnt[i].kpno;j++)
				{
				strcpy(ala[i].name[j],ptab[i].pname[j]);
				strcpy(ala[i].value[j],ptab[i].value[j]);
				}
			token=strtok(NULL,delim);
			while(token!=NULL)
			{
				if(strstr(token,"=")!=NULL)//if its a keyword parameter
				{
					j=0;
					while(token[j++]!='=');
					k=j;
					if(token[j]=='\0')
					{                       //without value means take default value from keyword ptable
						strcpy(ch,"");
					}
					else
					{
						l=0;
						while(token[j]!='\0')
						{
							ch[l++]=token[j++];
						}
						ch[l]='\0';
						token[k]='\0';
					}

					if(strstr(ptab[i].pname[temp_count],token)==NULL) //if in MACRO there is parameter with default value and if it is not define at the time of calling
					{                                                 //see e.g. CAL P,Q,LAB=LOOP actual prototype CALC &X &Y &OP=MULT &LAB=
                      //  printf("In strstr %s",token);
						strcpy(ala[i].name[temp_count],ptab[i].pname[temp_count++]);
						//strcpy(ala[i].value[temp_count++],"");
						strcpy(ala[i].name[temp_count],token);
						strcpy(ala[i].value[temp_count],ch);
					}
					else  //if parameter with default value
					{
						//printf("in else %s",token);
						strcpy(ala[i].name[temp_count],token);
						strcpy(ala[i].value[temp_count],ch);
					}
				}
				else           //if positional parameter
				{
					strcpy(ala[i].name[temp_count],token);
					//strcpy(ala[i].value[temp_count],ptab[i].value[]);
				}
				temp_count++;
				token=strtok(NULL,delim);
			}
			if(temp_count<(mnt[i].pno+mnt[i].kpno))
			{
				fprintf(fpw,"%s %s %c","Error: Less no of arguments while calling macro ",mnt[i].name,'\n');
				arg_flag=0;
			}
			else if(temp_count>(mnt[i].pno+mnt[i].kpno))
			{
				fprintf(fpw,"%s %s %c","Error: More no of arguments while calling macro ",mnt[i].name,'\n');
				arg_flag=0;
			}
			if(arg_flag==1)
			{
				for(j=0;j<mdt[i].instruct_count;j++) //Expanding
				{
					strcpy(s1,mdt[i].str[j]);
					fputs("+",fpw);
					token=strtok(s1,delim);
					while(token!=NULL)  //check each instruction of MACRO
					{
                        if(token[0]=='#')  //
                        {                  //GOT parameter
                              d=token[1]-48;  //convert to integer ACII 0=48

                            if(strstr(ala[i].name[d],"=")==NULL)
                        	{                                   //if keyword
                            	 fputs(ala[i].name[d],fpw);
                        	}
                             else
                            	{         //if positional
                            	 //printf("place: %s",ala[i].value[d]);
                            	 fputs(ala[i].value[d],fpw);
                            	}
                        	fputs(" ",fpw);
                        }
                        else
                           {
                        	fputs(token,fpw);
                        	fputs(" ",fpw);
                           }
						token=strtok(NULL,delim);
					}
					fputs("\n",fpw);
				}
			}
		}
		else//else copy as it is
		{
			fputs(s1,fpw);
		}
	}

	fclose(fpr);
	fclose(fpw);
}
int main(void)
{
	pass1();
	pass2();
	return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

// FOR INPUT...
typedef struct line
{
    char str1[10];
    char str2[10];
    char str3[10];
    char str4[10];
}line;

// MOT TABLE...
typedef struct mot
{
    int machine_code,no_of_op,chain,flag;
    char instruction[7];
    char type[3];
}mot;

// SYMBOL TABLE...
typedef struct symtab
{
    char symbol[10];
    int addr;
}symtab;

// LITERAL TABLE...

// INTERMEDIATE CODE...
typedef struct inter_code
{
    int LC;
    char type[3],optype; // type IS AD DL and optype which table i.e. S,L,C..etc
    int opcode;  //for machin code
    int operand1,operand2;
}inter_code;

// NUMBER OF SYMBOLS..
int cnt=0,lc=0,i=0;
line *l;
inter_code *ic;
mot m[26];
symtab s[10];


void create_mot();
void display_mot();
int search(char[]);
void pass1();
void IS(int ,int );
void DL(int );
void AD(int );
void sym_operand(char []);
void sym_label(char []);
void sym_dl(char S[]);
void eval_origin();
void eval_equ(char[]);
void test_operand(char [10]);
void pass2();

int main()
{
   create_mot();
   pass1();
  pass2();
    return 0;
}

void create_mot()
{
    char buffer[50],s1[10],s2[10],s3[10],s4[10];
    int i=0,start,j;
    FILE *fp1;
    for(j=0;j<26;j++)
    {
        strcpy(m[j].instruction," ");
        m[j].no_of_op=0;
        m[j].machine_code=0;
        strcpy(m[j].type," ");
    }

    fp1=fopen("/home/momin/workspace/SP/ass4Symbol/src/mot.txt","r");

    if(fp1==NULL)
    {
        printf("\n\t Unable to open file");
        exit(0);
    }
    for(i=0;i<26;i++)
    {
        m[i].chain=-1;
        m[i].flag=0;
    }
    while(fgets(buffer,50,fp1))
    {
        sscanf(buffer,"%s%s%s%s",s1,s2,s3,s4);

        start=s1[0]%65;
         //printf("\ninitial %d",start);
        while(m[start].flag==1)       //if already element present find next empty location
        {
            if(s1[0]%65==m[start].instruction[0]%65) //if same value element come
                break;
            start=(start+1)%65;
        }
        while(m[start].chain!=-1)  //to update chain find new placed element location
            start=m[start].chain;

        j=start;
        while(m[j].flag)  //find empty place
            j=(j+1)%65;

        strcpy(m[j].instruction,s1);
        m[j].machine_code=atoi(s2);
        m[j].no_of_op=atoi(s3);
        strcpy(m[j].type,s4);
        m[j].flag=1;
        if(j!=start)   //if element of same place create chain
            m[start].chain=j;
    }
    fclose(fp1);
      display_mot();
}

int search(char key[10])
{
    int j;
    j=key[0]%65;
    while(m[j].flag && (m[j].instruction[0]%65)!=(key[0]%65)) //traverse to find key
    {
        j=(j+1)%65;
    }
    if(!m[j].flag)
    {
      //printf("\n%s Instruction NOT FOUND in MOT TABLE.....",key);
        //  exit(0);
         return -1;
    }
    while(j!=-1)
    {
        if(strcmp(m[j].instruction,key)==0) //if found on jth location
              {
                 //printf("Found instruction ins=%s AND key=%s ",m[j].instruction,key);
                return j;
               }

        j=m[j].chain;//if key on chain
    }
          //printf("\n%s Instruction NOT FOUND in MOT TABLE.....",key);
          //exit(0);
    return -1;
}

void display_mot()
{
	int i;
	printf("\n---------------------------------------------------------");
	printf("\nSr.No. Instruction  machine_code No_of_operand  type  chain flag");
	printf("\n---------------------------------------------------------");

	for(i=0;i<26;i++)
	printf("\n %d     %s\t\t%d\t\t%d\t%s\t%d\t%d",i,m[i].instruction,m[i].machine_code,m[i].no_of_op,m[i].type,m[i].chain,m[i].flag);
	printf("\n---------------------------------------------------------");
}

void pass1()
{
    FILE *fp;
    int n,flag,j,t;
    char buffer[80];

    // INITIALSE SYMBOL TABLE..
    for(j=0;j<10;j++)
    {
        strcpy(s[j].symbol," ");
        s[j].addr=-1;
    }



    l=(line*)malloc(sizeof(line)*50);
    ic=(inter_code*)malloc(sizeof(inter_code)*50);
    fp=fopen("/home/momin/workspace/SP/ass4Symbol/src/input.txt","r");

    if(fp==NULL)
    {
        printf("\n\t Unable to open file");
        exit(0);
    }

 printf("\nIntermediate Code........\n");
    while(fgets(buffer,80,fp))
    {


    	//ic[i].operand1=-1;
    	ic[i].operand2=-1;
        n=sscanf(buffer,"%s%s%s%s",(l+i)->str1,(l+i)->str2,(l+i)->str3,(l+i)->str4);
        flag=search((l+i)->str1); //if 1st string is instrution
        if(flag==-1) //if 1st string is label
            {
             flag=search((l+i)->str2); //hence 2end will be instruction
             if(flag==-1)
               {printf("\nMnemonic error: %s Instruction NOT FOUND in MOT TABLE it may be invalid.....",(l+i)->str1);
                exit(0);
                }  
           }
        if(flag!=-1)
        {
            if(strcmp(m[flag].type,"IS")==0)
                IS(n,flag);
            else if(strcmp(m[flag].type,"AD")==0)
                AD(flag);
            else if(strcmp(m[flag].type,"DL")==0)
                DL(flag);


            if(ic[i].operand2==-1 && ic[i].operand1==0)
                   printf("\n\n%d\t(%s,%d)\n",ic[i].LC,ic[i].type,ic[i].opcode);
            else if(ic[i].operand1==0)
                     printf("\n\n%d\t(%s,%d)\t(%c,%d)\n",ic[i].LC,ic[i].type,ic[i].opcode,ic[i].optype,ic[i].operand2);
            else if(ic[i].operand2==-1)
            	printf("\n\n%d\t(%s,%d)\t(R,%d)\n",ic[i].LC,ic[i].type,ic[i].opcode,ic[i].operand1);

            else
            printf("\n\n%d\t(%s,%d)\t(R,%d)\t(%c,%d)\n",ic[i].LC,ic[i].type,ic[i].opcode,ic[i].operand1,ic[i].optype,ic[i].operand2);
        }

          i++;
    }
         for(t=0;t<cnt;t++)
            { 
                if(s[t].addr==-1)
                 {
                 printf("Error:Forward reference (Symbol used but not defined)");
                  exit(0);
                   }
             }
    printf("\n\nSr.No.\tSymbol\taddr\n");
        for(t=0;t<cnt;t++)
          printf("%d\t%s\t%d\n",t,s[t].symbol,s[t].addr);


}

void IS(int n,int f_key)
{
    int f,k,x;   //i is global
    strcpy(ic[i].type,m[f_key].type);
    ic[i].opcode=m[f_key].machine_code;
    ic[i].optype='S';
    if(n==4)   //line is like LABEL Mnemonic code OP1 Op2
    {

        //error handling for mnemonic
        f=search((l+i)->str2);
        if(f==-1)
        {
            printf("\n\nMnemonic error: Instruction not found");
            exit(0);
        }
        //error handling for reg
        x=((l+i)->str3[0])%65+1;  //there are four register
        if(x>4)
        {
            printf("\n\n Invalid register\n");
            exit(0);
        }
        else
        ic[i].operand1=x;
        sym_label((l+i)->str1);
        test_operand((l+i)->str4); //for 2end operand
    }
    else if(n==3)  // Mnemonic_code op1 op2
    {

        f=search((l+i)->str1);//check 1st string is Mnemonic code
        if(f==-1)  //if one operand instruction
        {
            //error handling for mnemonic
            x=search((l+i)->str2); //check for 2end string as Mnemonic code
            if(x==-1)
            {
                printf("\n\nMnemonic error: Instruction not found\n");
                exit(0);
            }
            //error handling for no. of operands
            if(m[x].no_of_op != 1)
            {
                printf("\n\nOperand Error: Invalid no. of operands\n");
                exit(0);
            }
            ic[i].operand1=0;
            test_operand((l+i)->str1);
            test_operand((l+i)->str3);
        }
        else  //if 2 operand instruction
        {
            //error handling for no. of operands
            if(m[f].no_of_op != 2)
            {
                printf("\n\nOperand Error:Invalid no. of operands\n");
                exit(0);
            }
            if(strcmp(m[f].instruction,"BC")==0)  //BC branch on condition e.g. (BC 2,label)
            {
                ic[i].operand1=0;
                for(k=0;k<cnt;k++)
                {
                    if(strcmp((l+i)->str3,s[k].symbol)==0)
                        ic[i].operand2=k;
                }
            }
            else
            {
                ic[i].operand1=((l+i)->str2[0])%65+1;
                test_operand((l+i)->str3);
            }
        }

    }
    ic[i].LC=lc++;
}
void sym_operand(char S[])
{
    int k,temp=0;
    // for symbol table..
        for(k=0;k<cnt;k++)  //cnt total symbole in symbole table
        {
            if(strcmp(S,s[k].symbol)==0) //if symbole already present
            {
                temp=1;
                ic[i].operand2=k;  //assign index only
            }

        }
        if(temp==0) //if symbol not present in symbol table
        {
            strcpy(s[cnt].symbol,S);
            if(strcmp(S,(l+i)->str1)==0)
                s[cnt].addr=lc;
            ic[i].operand2=cnt;
            cnt++;
        }
}
void test_operand(char data[10])  //to find operand is symbol or literal then accordingly insert in reppective table
{
    int k,flag1=0;
    for(k=0;data[k]!='\0';k++)
    {
        if(data[k]<'0' || data[k]>'9')//condition to check symbol or literal
        {
            flag1=1;
             break;
        }
    }
    if(flag1)  // if symbole
    {

        sym_operand(data);
    }
    else                   //if literal
    {
        ic[i].optype='C';
              ic[i].LC=lc;

    }
}

void sym_label(char S[])
{
    int k,temp1=0;
    // for symbol table..
        for(k=0;k<cnt;k++)
        {
            if(strcmp(S,s[k].symbol)==0) //if label already present in symbole table
            {
                temp1=1;
                ic[i].operand2=k; //assign only index
            }
        }
        if(temp1==0) //if new lable comes
        {
            strcpy(s[cnt].symbol,S);
            s[cnt].addr=lc;
            ic[i].operand2=cnt;
            cnt++;
        }
}

void DL(int flag)
{
    strcpy(ic[i].type,m[flag].type);
    ic[i].opcode=m[flag].machine_code;
    ic[i].operand1=0;
    ic[i].optype='C';
    ic[i].operand2=atoi((l+i)->str3);
    sym_dl((l+i)->str1);        //to assign address to symbol inserted before in symbol table

    if(strcmp(m[flag].instruction,"DS")==0)
    {
        ic[i].LC=lc;
        lc=lc+atoi((l+i)->str3);
    }
    else
        ic[i].LC=lc++;
}
void sym_dl(char S[])// to assign address to symbole inserted before in symbole table
{
    int k,temp1=0;
    for(k=0;k<cnt;k++)
        {
            if(strcmp(S,s[k].symbol)==0)  //if symbole present means use before declare
            {
                //error handling for duplication of symbol
                if(s[k].addr!=-1)
                {
                    printf("\n\n Duplication error\n");
                    exit(0);
                }
                temp1=1;
                s[k].addr=lc;
            }
        }
        if(temp1==0) //if symbole newly declare hence insert it in symbole table
        {
            strcpy(s[cnt].symbol,S);
            s[cnt].addr=lc;
            ic[i].operand2=atoi((l+i)->str3);
            cnt++;
        }
}
void AD(int flag) //if Assembler Directive stat.
{

    strcpy(ic[i].type,m[flag].type);
    ic[i].opcode=m[flag].machine_code;
    ic[i].optype='C';
    ic[i].operand1=0;
    if(strcmp((l+i)->str1,"START")==0)
    {
        ic[i].LC=atoi((l+i)->str2);
        ic[i].operand2=atoi((l+i)->str2);
        lc=atoi((l+i)->str2);                 //here is lc  initializtion
    }
    else if(strcmp((l+i)->str1,"END")==0)
    {
        ic[i].LC=lc;
        ic[i].operand2=0;

      }
    else if(strcmp((l+i)->str1,"ORIGIN")==0)
    {
        ic[i].LC=lc;
        eval_origin();
    }
    else if(strcmp((l+i)->str2,"EQU")==0)
    {
        ic[i].LC=lc;
        eval_equ((l+i)->str3);
    }
    else if(strcmp((l+i)->str1,"LTORG")==0)
    {
        ic[i].LC=lc;
        ic[i].operand2=0;
    }
    else
    {
        //error handlig
        printf("\n\nMnemonic error: Instruction not found");
        exit(0);
    }
}


void eval_origin()
{
    int k,t=0,flag1=0,flag2=0,j,x1;
    char symbol[10],operate;

    for(k=0;(l+i)->str2[k]!='\0';k++)
    {
        if(isdigit((l+i)->str2[k])==0)
        {
          flag1=1;
          break;
        }
    }
    if(flag1==0) //if direct address given jump to that address
    {
         printf("--------");
        lc=atoi((l+i)->str2);
        ic[i].operand2=lc;
    }
    for(k=0;(l+i)->str2[k]!='\0';k++)
    {
        if(isalpha((l+i)->str2[k])==0)
        {
            flag2=1;
            break;
        }
    }
    if(flag2==0)  //if label given take address from symbole table and jump to that address
    {
         printf("--------");
        for(k=0;k<cnt;k++)
        {
            if(strcmp((l+i)->str2,s[k].symbol)==0)
            {
                ic[i].operand2=s[k].addr;
                lc=s[k].addr;
            }
        }
    }

    if(flag1 & flag2)  //if combination of label and integer
    {
            //breaking process into label and integer value
        for(k=0;(l+i)->str2[k]!='\0';k++)
        {
            if(isalnum((l+i)->str2[k]))  //find label part
            {
                symbol[t++]=(l+i)->str2[k];
            }
            else
                break;
        }
        symbol[t]='\0'; //got label or symbole
         //printf("In ORIGIN instruction\n%s",symbol);
        operate=(l+i)->str2[k]; //got operator
        //printf("\n%c",operate);
        k++;
        x1=(int)((l+i)->str2[k]-'0'); //parse to integer part to int value
        //printf("\n%d",x1);
        for(j=0;j<cnt;j++)
        {
            if(strcmp(symbol,s[j].symbol)==0)
            {
                if(operate=='+')
                    lc=ic[i].operand2=s[j].addr + x1;
                else if(operate=='-')
                    lc=ic[i].operand2=s[j].addr - x1;
            }
        }
    }
}
void eval_equ(char S[])
{
    int k,flag=0,flag1=0,t=0,x1,j,x2;
    char symbol[10],operate;

    for(k=0;S[k]!='\0';k++)
    {
        if(isdigit(S[k])==0) //check for only address
           {
              flag=1;
              break;
           }
    }
    if(flag==0) //if direct address given
    {
        ic[i].operand2=atoi(S);
      //printf("\nin EQU %d",ic[i].operand2);
    }

    for(k=0;S[k]!='\0';k++)
    {
        if(!isalpha(S[k])) //check for only label
        {
            flag1=1;
            break;
        }
    }
    if(flag1==0)//if only label
    {
        for(k=0;k<cnt;k++)
        {
            if(strcmp(S,s[k].symbol)==0)
                ic[i].operand2=s[k].addr;
        }
    }
    if(flag & flag1) //if combination of label and address
    {
        for(k=0;S[k]!='\0';k++)
        {
            if(isalpha(S[k]))
            {
                symbol[t++]=S[k];
            }
            else
                break;
        }
        symbol[t]='\0';
        operate=S[k];
        k++;
        x1=(int)(S[k]-'0');
        for(j=0;j<cnt;j++)
        {
            if(strcmp(symbol,s[j].symbol)==0)
            {
                if(operate=='+')
                    ic[i].operand2=s[j].addr + x1;
                else if(operate=='-')
                    ic[i].operand2=s[j].addr - x1;
            }
        }
    }
    for(x2=0;x2<cnt;x2++) //search symbole in sym table
    {
        if(strcmp(s[x2].symbol,(l+i)->str1)==0)
            s[x2].addr=ic[i].operand2;
    }
}

void pass2()
{
   FILE *fp;
    int k,m,lcm,n=0; //m,lcm and n to traverse literal table need at LTORG and END

     fp=fopen("src/target.txt","w");
	if(fp==NULL)
	{
		printf("Cannot open");
		exit(0);
	}
	else
	{
		printf("\nTarget file generated\n");
		fprintf(fp,"LC\tMnemonic_code\tValue_of_Register\tAddress_of_Literal_or_Symbole\n");
	}


   for(k=0;k<i;k++)   //i contain total number 
   {

        if(strcmp(ic[k].type,"AD")==0)
        {

        	if(ic[k].opcode==1)  //for START
        	{

        		fprintf(fp,"%d  \n",ic[k].LC);
        	}

        }
        else if(strcmp(ic[k].type,"IS")==0)
        {
        	if(ic[k].optype=='C')
        	fprintf(fp,"%d\t\t+%d\t\t%d\t\t\n",ic[k].LC,ic[k].opcode,ic[k].operand1);

        	if(ic[k].optype=='S')
        	{
        		if(ic[k].opcode==0)   // for STOP
        		          fprintf(fp,"%d\n",ic[k].LC);
        		else
        			fprintf(fp,"%d\t\t+%d\t\t%d\t\t%d\n",ic[k].LC,ic[k].opcode,ic[k].operand1,s[ic[k].operand2].addr);
        	}
        }
       else if(strcmp(ic[k].type,"DL" )==0)
       {
    	 if(ic[k].opcode==2)// DS instruction
    	 {
    		 m=ic[k].operand2;
    		 fprintf(fp,"%d\n",ic[k].LC);
    		 lcm=ic[k].LC;
    		 n=2;
    		 while(n<=m)
    		 {
    			 lcm++;
    			 fprintf(fp,"%d\n",lcm);
    			 n++;
    		 }
    	 }
    	 else if(ic[k].opcode==1) // DC instruction
    	 {
    		 fprintf(fp,"%d\t\t+'%d'\n",ic[k].LC,ic[k].operand2);
    	 }
     }

   }
  printf("\n\n Target Code Written to target.txt file successfully......");
}



